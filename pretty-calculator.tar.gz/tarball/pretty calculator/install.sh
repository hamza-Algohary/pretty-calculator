cp pretty-calculator /usr/bin/pretty-calculator
cp my-calculator.desktop /usr/share/applications/pretty-calculator.desktop
