rm /usr/bin/pretty-calculator
rm /usr/share/applications/my-calculator.desktop
